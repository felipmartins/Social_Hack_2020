package com.example.verdeinbox;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

    public class SliderAdapter extends PagerAdapter{

        Context context;
        LayoutInflater layoutInflater;
        private Object RelativeLayout;

        public SliderAdapter(Context context){
            this.context = context;

        }

        public int[] slide_images = {
                R.drawable.caixa,
                R.drawable.salada,
                R.drawable.carro_logo
        };

        public String[] slide_headings = {
                "Descubra as caixas!",
                "Experimente nossas receitas!",
                "Saboreie em casa!"
        };

        public String[] slide_descs = {
                "Toda semana vários vegetais fresquinhos e diferenciados exclusivamente para você",
                "Todos os dias da semana saboreie uma receita nova da melhor qualidade",
                "Receba tudo isso no conforto e segurança de sua casa"
        };

        @Override
        public int getCount() {
            return slide_headings.length;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view ==(RelativeLayout) object;
        }

        public Object instantiateItem(ViewGroup container, int position) {

            layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            View view = layoutInflater.inflate(R.layout.slide_layout, container, false);

            ImageView slideImageView = (ImageView) view.findViewById(R.id.slide_image);
            TextView slideHeading = (TextView) view.findViewById(R.id.slide_heading);
            TextView slideDescription = (TextView) view.findViewById(R.id.slide_desc);

            slideImageView.setImageResource(slide_images[position]);
            slideHeading.setText((slide_headings[position]));
            slideHeading.setGravity(Gravity.CENTER);
            slideDescription.setText(slide_descs[position]);
            slideDescription.setGravity(Gravity.CENTER);

            container.addView(view);

            return view;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((RelativeLayout) object);
        }


    }
